#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
using namespace std;

// Function declarations
void readUserCredentials();
void writeUserCredentials();
void readFromFile();
void writeToFile();
string SignIn(string u_name, string pw);
bool SignUp(string u_name, string pw, string role);
int loginMenu();
void ClearScreen();
void Header();
int Admin_Menu();
int User_Menu();
void UserInterface();
void AdminInterface();
void Add_Contact();
void ViewCont();
void DelbyName();
void DelbyNumber();
void SbyName();
void SbyNumber();
void Display();
void update();
void DelAll();
void changePassword();
string SimCompany(string phoneNumber);
void changePassword1();
void logout();
void logoutLogo();

// Global variables
const int members = 100;
int counter = 0;
string usernameArr[members];
string passwordArr[members];
string roleArr[members];
string name[100];
string num[100];
int totalContacts = 0;
int k = 0;
// Function to read data from file
void readFromFile() {
    ifstream file("phonebook.txt");
    if (file.is_open()) {
        while (file >> name[totalContacts] >> num[totalContacts] ) {
            totalContacts++;
        }
        file.close();
    }
}

// Function to write data to file
void writeToFile()
 {
    ofstream file("phonebook.txt");
    if (file.is_open()) 
	{
        for (int i = 0; i < totalContacts; i++) 
		{
            file << name[i] << " " << num[i] <<  endl;
        }
        file.close();
    }
}

int main() {
	system("Color E0");
	readUserCredentials();
    // Read data from file when the program starts
    readFromFile();
    

    int loginOp;
    while (true) {
        system("CLS");
        Header();
        loginOp = loginMenu();
        if (loginOp == 1)
        {
            system("CLS");
        	Header();
            cout << "^^^^^^^^^^Welcome to Sign in Option^^^^^^^^^^" << endl;
            string u_name;
            string pw;
            string role;
            cout << "Enter username: ";
            cin >> u_name;
            cout << "Enter password: ";
            cin >> pw;
            system("CLS");
            role = SignIn(u_name, pw);
            if (role == "Admin")
            {
                AdminInterface();
            }
            else if (role == "User")
            {
                UserInterface();
            }
            else
            {
                cout << "You have entered wrong information" << endl;
                ClearScreen();
            }
        }
        else if (loginOp == 2)
        {
        	system("CLS");
        	Header();
        	cout << "^^^^^^^^^^Welcome to Sign up Option^^^^^^^^^^" << endl;
            string u_name, pw, role;
            cout << "Enter username: ";
            cin >> u_name;
            cout << "Enter password: ";
            cin >> pw;
            cout << "Enter your role (Admin or User): ";
            cin >> role;
            bool isPresent = SignUp(u_name, pw, role);
            if (isPresent)
            {
                cout << "You are signed up successfully." << endl;
            }
            writeUserCredentials();
            Sleep(1000);
            ClearScreen();
           
            if (!isPresent)
            {
                cout << "You are already signed up." << endl;
            }
            system ("CLS");
        }
        else if (loginOp == 3)
        {
        	cout<<"Thanks for coming!"<<endl;
            break; // Exit the application
        }
        else
        {
            cout << "Invalid option. Please choose a valid option." << endl;
        }
    }
    

    return 0;
}

string SignIn(string  u_name,string pw)
 {
 	           
    for(int i=0;i<members;i++)
    {
    	if(usernameArr[i]==u_name&&passwordArr[i]==pw)
    	{
    		return roleArr[i];
		}
	}
	return "Invalid Information";

}
bool SignUp(string u_name,string pw,string role)
{
   bool isPresent= false;
   for(int j=0; j<members; j++)
   {
   	if(usernameArr[j]==u_name&&passwordArr[j]==pw)
   	{
	isPresent=true;
   	break;
   }
}
    if(isPresent==true)
    {
    	cout<<"User already present."<<endl;
	}
	 else if(counter<members)
	 {
	 	usernameArr[counter]=u_name;
	 	passwordArr[counter]=pw;
	 	roleArr[counter]=role;
	 	counter++;
	 return true;
	 }
	 else
	 {
	 	return false;
		 }	
		 
}



int loginMenu()
{
	int op;
	cout<<"1. Signin with your credentials"<<endl;
	cout<<"2. Signup to get your credentials"<<endl;
	cout<<"3. Exit application"<<endl;
	cout<<"Chose an option from above given options:"<<endl;
	cout<<"Enter your option: ";
	cin>>op;
	system("CLS");
	return op;
}
void ClearScreen()
{
	cout<<"Press any key to continue.... ";
	getch();
	system ("CLS");
}
void AdminInterface()
{
	int check;
	system("CLS");
            Header();
	while(check!=12) 
	{
		 check= Admin_Menu();
		 
		if (check==1)
		{
			system("CLS");
            Header();
			Add_Contact();
			writeToFile();
			
		}
		else if (check==2)
		{
		system("CLS");
        Header();
		ViewCont();
		}
		
		else if(check==3)
		{
			system("CLS");
            Header();
			SbyName();
}
		else if(check==4)
		{
			system("CLS");
            Header();
			SbyNumber();
		
		}
	else if (check == 5)
	 {
	 	system("CLS");
        Header();
        DelbyNumber();
        writeToFile();
		}
			else if (check == 6) 
			{
				system("CLS");
                Header();
                DelbyName();
                writeToFile();

		}
		
		else if (check == 7)
		 {
		 	system("CLS");
            Header();
		 	update();
		 	writeToFile();
		}
	
			
		else if(check==8)
		{
			system("CLS");
             Header();
			Display();
			
			}	
		else if(check==9)
		{
			system("CLS");
            Header();			
            DelAll();
               
            }
        else if(check==10)
        {
        	system("CLS");
            Header(); 
        	changePassword1();
		}
		 else if(check==11)
        {
        system("CLS");
            logout();
            break;
		}
		
		else
		{
			cout<<"Wrong input"<<endl;
				
				}    	
			
	}

}
int Admin_Menu()
{
	int option;
	cout<<"----------------------------"<<endl;
	cout<<"Phone Book Management System"<<endl;
	cout<<"----------------------------"<<endl;
	cout<<"1---> Add Contacts "<<endl;
	cout<<"2---> View All Contacts"<<endl;
	cout<<"3---> Search Contact by Name "<<endl;
	cout<<"4---> Search Contact by Number "<<endl;
	cout<<"5---> Delete Contact by Number "<<endl;
	cout<<"6---> Delete Contact by Name "<<endl;
	cout<<"7---> Update Contacts "<<endl;
	cout<<"8---> Display All Contacts "<<endl;
    cout<<"9---> Delete All Contacts "<<endl;
	cout<<"10--->Change Password "<<endl;
	cout<<"11--->Logout "<<endl;
	cout<<" Enter your option: ";
	cin>>option;
	system("CLS");
	return option;
}
int User_Menu()
{
	int option;
	cout<<"----------------------------"<<endl;
	cout<<"Phone Book Management System"<<endl;
	cout<<"----------------------------"<<endl;
	cout<<"1) Add Contacts "<<endl;
	cout<<"2) Search Contact by Name "<<endl;
	cout<<"3) Search Contact by Number "<<endl;
	cout<<"4) Delete Contact by Number "<<endl;
	cout<<"5) Delete Contact by Name "<<endl;
	cout<<"6)Change Password"<<endl;
	cout<<"7) Logout "<<endl;
	cout<<" Enter your option: ";
	cin>>option;
	system("CLS");
	return option;
}
void UserInterface()
{
	int check;
	while(check!=10) 
	{
		check=User_Menu();
		 
		if (check==1)
		{
			system("CLS");
            Header();
			Add_Contact();
			
		}
		else if (check==2)
		{
		system("CLS");
        Header();	
		SbyName();
		}
		
		else if(check==3)
		{
			system("CLS");
            Header();
			SbyNumber();
}
		else if(check==4)
		{
			system("CLS");
            Header();
		DelbyNumber();
		}
	else if (check == 5) {
		system("CLS");
        Header();
        DelbyName();
		}
			else if (check == 6) {
				system("CLS");
                Header();        
              changePassword();

		}
		else if (check == 7) {
            
         system("CLS");
            logout();
            break;

		}
        else
		{
			cout<<"Wrong input"<<endl;
				}    	
			
	}
	
}

void Add_Contact()
{
	
	cout<<"^^^^^^^^^^Welcome to Add Contact Section^^^^^^^^^^"<<endl;
	cout<<"Enter your Name: ";
			cin>>name[k];
			cout<<"Enter your Phone No. (11 Digits) : ";
			cin>>num[k];
			string Company = SimCompany(num[k]);
    cout << "SIM Company: " << Company << endl;
    string firstFourDigits = num[k].substr(0, 4);
    if (firstFourDigits < "0300" || firstFourDigits > "0349") 
	{
    	name[k]="\0";
        cout <<"The entered number is not within the range of 0300 to 0349."<< endl;
    }
        
	if(num[k].length()!=11)
    {
    	cout<<"You have entered an invalid number(number length not completed)"<<endl;
    	return;
	}
			k++;
			totalContacts++;
			writeToFile();
			ClearScreen();
}
void ViewCont()
{
	    cout<<"^^^^^^^^^^Welcome to View Contact Section^^^^^^^^^^"<<endl;
		for(int i=0; i<k; i++)
			{
				string Company = SimCompany(num[i]);
				if(name[i]!="Nill")
				cout<<"Name:"<<name[i]<<"    Phone Number: "<<num[i]<<"      Sim Company: "<< Company <<endl;
			}
			
	ClearScreen();
}
void SbyName() 
{
	cout<<"^^^^^^^^^^Welcome to Search (by name) Contact Section^^^^^^^^^^"<<endl;
    string name1;
    cout << "Enter the Contact Name: ";
    cin >> name1;
    int count = 0;
    for (int i = 0; i < k; i++) {
        if (name1 == name[i]) {
            count = i;
            cout << "Your entered contact name is searched." << endl;
            string Company = SimCompany(num[i]);
            cout << "Name: " << name[i] << "    Phone Number: " << num[i] << "    SIM Company: " << Company << endl;
            break;
        }
    }
    if (name1 != name[count]) {
        cout << "You have entered the wrong contact name." << endl;
    }
    ClearScreen();
    
}
void SbyNumber()
 {
 		cout<<"^^^^^^^^^^Welcome to Search (by number) Contact Section^^^^^^^^^^"<<endl;
    string num1;
    cout << "Enter a Phone Number: ";
    cin >> num1;
    for (int i = 0; i < k; i++)
	 {
        if (num1 == num[i]) 
		{
            cout << "Your entered phone number is searched." << endl;
            string Company = SimCompany(num[i]);
            cout << "Name: " << name[i] << "    Phone Number: " << num[i] << "    SIM Company: " << Company << endl;
            break;
        } else 
		{
            cout << "You have entered the wrong number." << endl;
            break;
        }
    }
    ClearScreen();
}

void DelbyNumber()
{
		cout<<"^^^^^^^^^^Welcome to Delete (by number) Contact Section^^^^^^^^^^"<<endl;

	string dnum;
            bool found ;
            cout << "Enter Number of Contact which you want to delete: ";
            cin >> dnum;
            for (int i = 0; i < k; i++) {
                if (dnum == num[i]) {
                    cout << "Contact deleted successfully." << endl;
                    name[i] = "\0";
                    num[i] = "\0";
                    cout << "Name: " << name[i] << "     Phone Number: " << num[i] << endl;
                    found = true;
                    break;  
                    totalContacts--;
                }
            }
            if (!found) {
                cout << "You entered contact is not found. Please try again." << endl;
            }
ClearScreen();
}
void DelbyName()
{
		cout<<"^^^^^^^^^^Welcome to Delete (by name) Contact Section^^^^^^^^^^"<<endl;

	string dname;

            bool found ;
            cout << "Enter Name of Contact which you want to delete: ";
            cin >> dname;
            for (int i = 0; i < k; i++) {
                if (dname == name[i]) {
                    cout << "Contact deleted successfully." << endl;
                    name[i] = "\0";
                    num[i] = "\0";
                  
                    
                    cout << "Name: " << name[i] << "     Phone Number: " << num[i] << endl;
                    found = true;
                    break;  
                }
                
            }
            if (!found) {
                cout << "You entered contact is not found. Please try again." << endl;
            }
ClearScreen();
}
void Display()
{
		cout<<"^^^^^^^^^^Welcome to Display All Contacts Section^^^^^^^^^^"<<endl;

	cout<<"Total contacts in this Phone Book are: "<<totalContacts<<endl;
			for(int i=0; i<totalContacts; i++)
			{
				string Company = SimCompany(num[i]);
			  cout<<"Name:"<<name[i]<<"      Phone Number:"<<num[i]<< "    SIM Company: " << Company << endl;     	
			}
			
			ClearScreen();
}
void update() {
		cout<<"^^^^^^^^^^Welcome to Update Contacts Section^^^^^^^^^^"<<endl;

    bool found = true;
    string name1, Nname1, Nname2;
    cout << "Enter the Contact Name: ";
    cin >> name1;
    int i;
    for (i = 0; i < totalContacts; i++) {
        if (name1 == name[i]) {
            cout << "Enter new name: ";
            cin >> Nname1;
            cout << "Enter new number: ";
            cin >> Nname2;
            string Company = SimCompany(Nname2);
            cout << "Name: " << name[i] << "    Phone Number : " << num[i] << "    SIM Company: " << Company << endl;
            name[i] = Nname1;
            num[i] = Nname2;
            cout << "Contact is successfully updated." << endl;
            break;
      
        }
    }
    if (i == totalContacts) {
        cout << "You entered contact is not found. Please try again." << endl;
    }
    ClearScreen();
}
void DelAll()
{
	cout<<"^^^^^^^^^^Welcome to Delte All Contacts Section^^^^^^^^^^"<<endl;

	cout << "All Contacts are deleted successfully." << endl;
                    
                    for(int i=0; i<k; i++)
                    {
                    	name[i]="\0";
                    	num[i]="\0";
    
					}
					k=0; 
					totalContacts=0; 
            }
    string SimCompany(string phoneNumber)
            {
			
	string Company;
    if (phoneNumber.substr(0, 4) == "0300" || phoneNumber.substr(0, 4) == "0301" || phoneNumber.substr(0, 4) == "0302" || phoneNumber.substr(0, 4) == "0303" || phoneNumber.substr(0, 4) == "0304"|| phoneNumber.substr(0, 4) == "0305"|| phoneNumber.substr(0, 4) == "0306"|| phoneNumber.substr(0, 4) == "0307"|| phoneNumber.substr(0, 4) == "0308"|| phoneNumber.substr(0, 4) == "0309") {
        Company = "Jazz";
    } else if (phoneNumber.substr(0, 4) == "0310" || phoneNumber.substr(0, 4) == "0311" || phoneNumber.substr(0, 4) == "0312" || phoneNumber.substr(0, 4) == "0313"|| phoneNumber.substr(0, 4) == "0314"|| phoneNumber.substr(0, 4) == "0315"|| phoneNumber.substr(0, 4) == "0316"|| phoneNumber.substr(0, 4) == "0317"|| phoneNumber.substr(0, 4) == "0318"|| phoneNumber.substr(0, 4) == "0319") 
	{
        Company = "Zong";
    } else if (phoneNumber.substr(0, 4) == "0320" || phoneNumber.substr(0, 4) == "0321" || phoneNumber.substr(0, 4) == "0322" || phoneNumber.substr(0, 4) == "0323"||phoneNumber.substr(0, 4) == "0324"||phoneNumber.substr(0, 4) == "0325"||phoneNumber.substr(0, 4) == "0326"||phoneNumber.substr(0, 4) == "0327"||phoneNumber.substr(0, 4) == "0328"||phoneNumber.substr(0, 4) == "0329") 
	{
        Company = "Warid";
    } else if (phoneNumber.substr(0, 4) == "0330" || phoneNumber.substr(0, 4) == "0331" || phoneNumber.substr(0, 4) == "0332" || phoneNumber.substr(0, 4) == "0333"|| phoneNumber.substr(0, 4) == "0334"|| phoneNumber.substr(0, 4) == "0335"|| phoneNumber.substr(0, 4) == "0336"|| phoneNumber.substr(0, 4) == "0337"|| phoneNumber.substr(0, 4) == "0338"|| phoneNumber.substr(0, 4) == "0339") 
	{
        Company = "Ufone";
    } else if (phoneNumber.substr(0, 4) == "0340" || phoneNumber.substr(0, 4) == "0341" || phoneNumber.substr(0, 4) == "0342" || phoneNumber.substr(0, 4) == "0343"|| phoneNumber.substr(0, 4) == "0344"|| phoneNumber.substr(0, 4) == "0345"|| phoneNumber.substr(0, 4) == "0346"|| phoneNumber.substr(0, 4) == "0347"|| phoneNumber.substr(0, 4) == "0348"|| phoneNumber.substr(0, 4) == "0349")
	 {
        Company = "Telenor";
    } else 
	{
        Company = "Unknown";
    }

    return Company;

}

void logoutLogo()
 {
    cout << "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" << endl;
    cout << "%                             %" << endl;
    cout << "%                             %" << endl;
    cout << "%     Successfully Logout     %" << endl;
    cout << "%                             %" << endl;
    cout << "%                             %" << endl;
    cout << "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" << endl;
}
void Header()
{
	cout<<"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"<<endl;
	cout<<"^^^^^^^^^^^^^^^^^^^^^^Phone Book Management System^^^^^^^^^^^^^^^^^^^^^^^^^"<<endl;
	cout<<"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"<<endl;

}
void logout()
{
    logoutLogo();
    cout<<endl;
	cout<<"Thank you for coming"<<endl;
	ClearScreen();
}

void changePassword()
{
    string enteredOldUsername, enteredOldPassword;
    cout << "Enter old username: ";
    cin >> enteredOldUsername;
     cout << "Enter old password: ";
    cin >> enteredOldPassword;

    bool check_record = false;
    for (int i = 0; i < counter; i++)
    {
        if (usernameArr[i] == enteredOldUsername)
        {
            int attempts = 3; // Number of allowed attempts

            while (attempts > 0)
            {
            	

                if (usernameArr[i]==enteredOldUsername&&passwordArr[i] == enteredOldPassword)
                {
                    cout << "Enter new username: ";
                    cin >> usernameArr[i];
					cout << "Enter new password: ";
                    cin >> passwordArr[i];
                    check_record = true;
                    cout << "Password has been successfully changed." << endl;
                    break;
                }
                else
                {
                    attempts--;
                    cout << "Incorrect old username or password. You have " << attempts << " attempts left." << endl;
                }
            }

            if (!check_record)
            {
                cout << "You have exceeded the maximum number of attempts. Please try again later." << endl;
            }
        }
    }

    if (!check_record)
    {
        cout << "No record found for the entered old username." << endl;
    }

    ClearScreen();
    UserInterface();
}
void changePassword1()
{
    string enteredOldUsername, enteredOldPassword;
    cout << "Enter old username: ";
    cin >> enteredOldUsername;
     cout << "Enter old password: ";
    cin >> enteredOldPassword;

    bool check_record = false;
    for (int i = 0; i < counter; i++)
    {
        if (usernameArr[i] == enteredOldUsername)
        {
            int attempts = 3; // Number of allowed attempts

            while (attempts > 0)
            {
            	
                

                if (usernameArr[i]==enteredOldUsername&&passwordArr[i] == enteredOldPassword)
                {
                    cout << "Enter new username: ";
                    cin >> usernameArr[i];
					cout << "Enter new password: ";
                    cin >> passwordArr[i];
                    check_record = true;
                    cout << "Password has been successfully changed." << endl;
                    break;
                }
                else
                {
                    attempts--;
                    cout << "Incorrect old username or password. You have " << attempts << " attempts left." << endl;
                }
            }

            if (!check_record)
            {
                cout << "You have exceeded the maximum number of attempts. Please try again later." << endl;
            }
        }
    }

    if (!check_record)
    {
        cout << "No record found for the entered old username." << endl;
    }

    ClearScreen();
    AdminInterface();
}
void writeUserCredentials() 
{
    ofstream userFile("user_credentials.txt");
    if (userFile.is_open()) {
        for (int i = 0; i < counter; i++) {
            userFile << usernameArr[i] << " " << passwordArr[i] << " " << roleArr[i] << endl;
        }
        userFile.close();
    }
}
void readUserCredentials() {
    ifstream userFile ("user_credentials.txt");
    if (userFile.is_open()) {
        while (userFile >> usernameArr[counter] >> passwordArr[counter] >> roleArr[counter]) {
            counter++;
        }
        userFile.close();
    }
}

